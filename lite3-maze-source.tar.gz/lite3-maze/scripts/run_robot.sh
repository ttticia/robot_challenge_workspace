#!/usr/bin/env bash
set -eo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
if [[ ! ${1:-} =~ ^[0-9]+$ ]]; then echo 'Usage: run_robot.sh DOMAIN_ID [launch args]' >&2; exit 2; fi
domain=$1
shift
source "$root/scripts/env.sh" robot "$domain"
python=${MAZE_PYTHON:-$root/.venv/bin/python}
if [[ ! -x $python && -x /home/vicdeo/ir_challenge/.venv/bin/python ]]; then python=/home/vicdeo/ir_challenge/.venv/bin/python; fi
if [[ ! -x $python ]]; then python=/usr/bin/python3; fi
echo 'Waiting for lite3_auto. Starting the course SLAM includes; stack:=false uses an existing stack.'
exec ros2 launch lite3_maze maze.launch.py stack:=true perception_python:="$python" "$@"
